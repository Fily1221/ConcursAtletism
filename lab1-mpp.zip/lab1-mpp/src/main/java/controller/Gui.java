package controller;


import org.graalvm.compiler.phases.common.NodeCounterPhase;

import java.awt.*;

public class Gui {

    @Override
    public void start(NodeCounterPhase.Stage stage) throws Exception {
        GridPane gridLogin;
        gridLogin = new GridPane();
        gridLogin.setPadding(new Insets(10, 10, 10, 10));
        gridLogin.setVgap(5);
        gridLogin.setHgap(5);

        Label lbUser = new Label("Utilizator: ");
        Label lbPwd = new Label("Parola: ");

        TextField txtUser = new TextField();
        txtUser.setPromptText("nume utilizator");
        TextField txtPwd = new TextField();
        txtPwd.setPromptText("parola");

        Button btnLogin = new Button("Login");

        GridPane.setConstraints(lbUser, 0, 1);
        gridLogin.getChildren().add(lbUser);
        GridPane.setConstraints(txtUser, 1, 1);
        gridLogin.getChildren().add(txtUser);
        GridPane.setConstraints(lbPwd, 0, 2);
        gridLogin.getChildren().add(lbPwd);
        GridPane.setConstraints(txtPwd, 1, 2);
        gridLogin.getChildren().add(txtPwd);
        GridPane.setConstraints(btnLogin, 1, 3);
        gridLogin.getChildren().add(btnLogin);
    }
}

