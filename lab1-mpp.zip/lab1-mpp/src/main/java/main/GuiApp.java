package main;

import controller.Gui;

public class GuiApp {
    private static Gui gui = new Gui();
    public static void main(String[] args) {
        gui.startApp(args);

    }
}
