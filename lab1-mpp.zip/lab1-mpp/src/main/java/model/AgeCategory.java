package model;

public class AgeCategory implements HasId<Integer> {
    private Integer ID;
    private Integer minAge;
    private Integer maxAge;

    public AgeCategory() {
    }

    public AgeCategory(Integer ID, Integer minAge, Integer maxAge) {
        this.ID = ID;
        this.minAge = minAge;
        this.maxAge = maxAge;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    @Override
    public String toString() {
        return "AgeCategory{" +
                "ID=" + ID +
                ", minAge=" + minAge +
                ", maxAge=" + maxAge +
                '}';
    }
}