package model;

public class Trial implements HasId<Integer> {
    private Integer ID;
    private String name;
    private Float duration;

    public Trial() {
    }

    public Trial(Integer ID, String name, Float duration) {
        this.ID = ID;
        this.name = name;
        this.duration = duration;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getDuration() {
        return duration;
    }

    public void setDuration(Float duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Trial{" +
                "ID=" + ID +
                ", name='" + name + '\'' +
                ", duration=" + duration +
                '}';
    }
}