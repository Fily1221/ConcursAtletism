package model;

public class User implements HasId<String> {
    private String ID;
    private String password;

    public User() {
    }

    public User(String ID, String password) {
        this.ID = ID;
        this.password = password;
    }

    @Override
    public String getID() {
        return ID;
    }

    @Override
    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
