package model;


public class Entry implements HasId<Integer> {
    private Integer ID;
    private Integer ageCategoryID;
    private Integer trialID;
    private Integer childAge;
    private String childName;

    public Entry() {
    }

    public Entry(Integer ID, Integer ageCategoryID, Integer trialID, Integer childAge, String childName) {
        this.ID = ID;
        this.ageCategoryID = ageCategoryID;
        this.trialID = trialID;
        this.childAge = childAge;
        this.childName = childName;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public Integer getAgeCategoryID() {
        return ageCategoryID;
    }

    public void setAgeCategoryID(Integer ageCategoryID) {
        this.ageCategoryID = ageCategoryID;
    }

    public Integer getTrialID() {
        return trialID;
    }

    public void setTrialID(Integer trialID) {
        this.trialID = trialID;
    }

    public Integer getChildAge() {
        return childAge;
    }

    public void setChildAge(Integer childAge) {
        this.childAge = childAge;
    }

    public String getChildName() {
        return childName;
    }

    public void setChildName(String childName) {
        this.childName = childName;
    }

    @Override
    public String toString() {
        return "Entry{" +
                "ID=" + ID +
                ", ageCategoryID=" + ageCategoryID +
                ", trialID=" + trialID +
                ", childAge=" + childAge +
                ", childName='" + childName + '\'' +
                '}';
    }
}