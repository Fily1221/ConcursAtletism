package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EntryRepo implements IEntryRepo {



    @Override
    public void AddEntry(int id, int ageCategoryId, int trialId, int childAge, String childName) {
        JdbcConnect.openConnection();
        try(Statement stmt= JdbcConnect.conn.createStatement()){
            PreparedStatement preStmt = JdbcConnect.conn.prepareStatement("insert into Entry(id, ageCategoryId, trialId,childAge,childName) values(?, ?, ?, ?, ?)");
            preStmt.setInt(1, id);
            preStmt.setInt(2, ageCategoryId);
            preStmt.setInt(3, trialId);
            preStmt.setInt(4, childAge);
            preStmt.setString(5, childName);
            preStmt.executeUpdate();
            //  SpectacolRepo sRepo = new SpectacolRepo();
            // sRepo.updateLocuri(nrLoc_dorit, spectacol_id);
        }catch(SQLException ex){
            System.err.println("EXCEPTION IN EntryRepo: ");
            System.err.println(ex.getSQLState());
            System.err.println(ex.getErrorCode());
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public String PrintEntry() {
        JdbcConnect.openConnection();
        String result = "\n-------------------------------------------------------\nRegistration:\n-------------------------------------------------------\n";
        try {
            PreparedStatement preStmt = JdbcConnect.conn.prepareStatement(
                    "SELECT * FROM Entry");
            ResultSet rs = preStmt.executeQuery();

            while(rs.next()){
                result += "Age Category Id: " + rs.getString("ageCategoryId") +
                        "\nTrial Id: " + rs.getString("trialId") +
                        "\nChild Age: " + rs.getString("childAge") +
                        "\nChild Name: " + rs.getString("childName") +"\n\n";
            }
            result += "\n-------------------------------------------------------\n";
        } catch (SQLException ex) {
            System.err.println(ex.getSQLState());
            System.err.println(ex.getErrorCode());
            System.err.println(ex.getMessage());
        }
        return result;
    }
}
