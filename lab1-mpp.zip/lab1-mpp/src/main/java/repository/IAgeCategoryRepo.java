package repository;

public interface IAgeCategoryRepo {
    String afisare();

    String cautare(String var1);
}
