package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AgeCategoryRepo implements IAgeCategoryRepo {

    public AgeCategoryRepo(){}

    @Override
    public String afisare() {

        JdbcConnect.openConnection();
        String result = "\n------------------------\nToate categoriile de varsta\n------------------------\n";

        try {
            PreparedStatement preStmt = JdbcConnect.conn.prepareStatement("SELECT  minAge,maxAge from AgeCategory");

            for(ResultSet rs = preStmt.executeQuery(); rs.next(); result = result + "Varsta Minima: " + rs.getString(1) + "\nVarsta Maxima: ") {
            }

            result = result + "\n------------------------\n";
        } catch (SQLException var4) {
            System.err.println(var4.getSQLState());
            System.err.println(var4.getErrorCode());
            System.err.println(var4.getMessage());
        }

        return result;
    }

    @Override
    public String cautare(String var1) {
        return null;
    }
}
