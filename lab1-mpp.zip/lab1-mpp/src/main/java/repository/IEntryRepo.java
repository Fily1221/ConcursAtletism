package repository;

public interface IEntryRepo {
    void AddEntry(int id,int ageCategoryId,int trialId,int childAge, String childName);
    String PrintEntry();
}
