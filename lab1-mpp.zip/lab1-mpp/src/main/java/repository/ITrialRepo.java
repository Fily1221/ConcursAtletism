package repository;

public interface ITrialRepo {
    void update(int nrLoc_dorit, String spectacol_id);
}
