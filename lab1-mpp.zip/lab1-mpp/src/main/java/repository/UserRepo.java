package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRepo {
    public boolean validate(String id, String password){
        JdbcConnect.openConnection();
        try {
            PreparedStatement preStmt = JdbcConnect.conn.prepareStatement("select * from users where id=? and password=?");
            preStmt.setString(1, id);
            preStmt.setString(2, password);
            ResultSet rs = preStmt.executeQuery();
            rs.next();
            if(rs.getString("id") != null)
                return true;
        } catch (SQLException ex) {
            System.err.println(ex.getSQLState());
            System.err.println(ex.getErrorCode());
            System.err.println(ex.getMessage());
        }
        return false;
    }
}
