package repository;

public class TrialRepo implements ITrialRepo{
    @Override
    public void update(int nrLoc_dorit, String spectacol_id) {

    }
}
