package repository;



public interface IUserRepo {
    boolean validate(String id, String password);

}
