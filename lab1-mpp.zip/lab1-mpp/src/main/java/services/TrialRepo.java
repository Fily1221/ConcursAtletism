package services;

public class TrialRepo {
}
