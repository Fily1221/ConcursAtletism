package services;

public interface ITrialRepo {
}
